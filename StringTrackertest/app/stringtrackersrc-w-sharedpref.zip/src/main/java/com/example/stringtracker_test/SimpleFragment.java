package com.example.stringtracker_test;

public class SimpleFragment {
}
