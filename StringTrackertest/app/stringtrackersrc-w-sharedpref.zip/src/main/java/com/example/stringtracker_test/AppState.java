package com.example.stringtracker_test;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static android.content.Context.MODE_PRIVATE;
import static android.support.v4.content.FileProvider.getUriForFile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

// StringTracker top level app state class with supporting functions   WKD 3-21-21
public class AppState extends Activity { //AppCompatActivity {
    private final String filename =  "STRunState.dat";  // fixed filename for entire app
    //path to data files on /sdcard (required) note that /system is a read-only file system
    private final String path = "/sdcard/Documents/StringTrackerData/";

    private static boolean FirstRun;       // flag to indicate initial run of app for setup purposes
    private static int InstrumentID;                // currently selected instrument
    private static boolean SessionStarted;     // set true at Start button event, false at Stop event
    private static boolean EnableSent;         // pref - enable user sent feedback
    private static int MaxSessionTime;         // max time for any given session
    private static int LastSessionTime;        // time for last session upon stop event
    private static int[] LifeThresholds = new int[4]; // thresholds for color coding
    private static int StringsCnt;             // to globally track number of strings and instruments added
    private static int InstrumentCnt;
    private static String CurrSessionStart;    // timestamp for start of current session

    private static long StartT, StopT;         // internal timestamps in mSec
    private static boolean testMode;           // true sets timescale to 0.01 sec instead of 1 min for session time

    // Constructors
    AppState(){      // defaults
        FirstRun = false;
        InstrumentID = 0;
        SessionStarted = false;
        EnableSent = false;
        MaxSessionTime = 180;  // 3 hour default
        LastSessionTime = 0;
        LifeThresholds[0] = 0;
        LifeThresholds[1] = 75;
        LifeThresholds[2] = 90;
        LifeThresholds[3] = 100;
        StringsCnt = 0;
        InstrumentCnt = 0;
        CurrSessionStart = null;
        StartT = 0;
        StopT = 0;
        testMode = false;
    }

    AppState( int insid, boolean sstart, boolean ensent, int maxsess, int lastsess,
                 int [] lifet, int scnt, int icnt, String currses){
        FirstRun = false;
        InstrumentID = insid;
        SessionStarted = sstart;
        EnableSent = ensent;
        MaxSessionTime = maxsess;  // 3 hour default
        LastSessionTime = lastsess;
        LifeThresholds = lifet;
        StringsCnt = scnt;
        InstrumentCnt = icnt;
        CurrSessionStart = currses;
        StartT = 0;
        StopT = 0;
        testMode = false;
    }

    // Method returns this state value for initialization sequence
    public boolean firstRun() {
        return FirstRun;
    }

    // Method called by Start button click event
    public void startSession() {
        SessionStarted = true;
        CurrSessionStart = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date());
        StartT = System.currentTimeMillis();
    }

    // Method called by Stop button click event or selecting another instrument
    public void stopSession() {
        SessionStarted = false;
        String CurrSessionStop = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date());
        StopT = System.currentTimeMillis();
        if(testMode) {
            // 100ths of a sec time unit for testMode
            LastSessionTime = (int) TimeUnit.MILLISECONDS.toMillis(StopT - StartT) / 10;
        } else {
            // minutes played for normal operation
            LastSessionTime = (int) TimeUnit.MILLISECONDS.toMinutes(StopT - StartT) ;
        }

        if(LastSessionTime > MaxSessionTime) {   // truncate time if too long
            LastSessionTime = MaxSessionTime;
        }
    }


    // Method returns a string of AppState data using comma delimiters
    public String getAppState(){
        String delim = ", ";

        String outstr =
                String.valueOf(InstrumentID)+delim+
                        String.valueOf(SessionStarted)+delim+
                        String.valueOf(EnableSent)+delim+
                        String.valueOf(MaxSessionTime)+delim+
                        String.valueOf(LastSessionTime)+delim+
                        String.valueOf(LifeThresholds[0])+delim+
                        String.valueOf(LifeThresholds[1])+delim+
                        String.valueOf(LifeThresholds[2])+delim+
                        String.valueOf(LifeThresholds[3])+delim+
                        String.valueOf(StringsCnt)+delim+
                        String.valueOf(InstrumentCnt)+delim+
                        CurrSessionStart+delim+
                        String.valueOf(StartT)+delim+
                        String.valueOf(StopT);
        return outstr;
    }


    // Method to set App State parameters from a string using comma delimiters
    public void setAppState(String line){
        if (line != null) {
            String tokens[] = line.split(",");

            InstrumentID = Integer.parseInt(tokens[0].trim());
            SessionStarted = Boolean.parseBoolean(tokens[1].trim());
            EnableSent = Boolean.parseBoolean(tokens[2].trim());
            MaxSessionTime = Integer.parseInt(tokens[3].trim());
            LastSessionTime = Integer.parseInt(tokens[4].trim());
            LifeThresholds[0] = Integer.parseInt(tokens[5].trim());
            LifeThresholds[1] = Integer.parseInt(tokens[6].trim());
            LifeThresholds[2] = Integer.parseInt(tokens[7].trim());
            LifeThresholds[3] = Integer.parseInt(tokens[8].trim());
            StringsCnt = Integer.parseInt(tokens[9].trim());
            InstrumentCnt = Integer.parseInt(tokens[10].trim());
            CurrSessionStart = tokens[11];
            StartT = Long.parseLong(tokens[12].trim());
            StopT = Long.parseLong(tokens[13].trim());
        }
    }

    // Method to init() the app which should run in main activity onCreate().
    // Checks for run state file existence then runs loadRunState() if run state file exists.
    // Otherwise it sets the FirstRun flag and returns value to main activity.
    // This implies default values are used.
    public boolean init() {
        File filechk = new File(path+filename);
        if(filechk.exists()) {
            loadRunState();  // if file exists load the data
            FirstRun = false;
        } else {
            File f = new File(path);
            f.mkdirs();   // create missing directories path
            saveRunState();  // add the first AppState file
            FirstRun = true;    // we may want to add other criterion here
        }
        return FirstRun;
    }

    // method returns true if app state file exists DEBUG purposes?
    boolean fileExists() {
        File filechk = new File( path+filename);
        return filechk.exists();
    }

    // Method to load app run state from app state file
    public void loadRunState() {
        String line = null;

        File data = new File(path+filename);
        // reads in one line of text then parses data
        try {
            InputStream f = new FileInputStream(data);
            BufferedReader br = new BufferedReader(new InputStreamReader(f));
            line = br.readLine();
            br.close();
        } catch (IOException e) {
             e.printStackTrace();
        }

        //parse if valid data
        if (line != null) {
            String tokens[] = line.split(",");

            InstrumentID = Integer.parseInt(tokens[0].trim());
            SessionStarted = Boolean.parseBoolean(tokens[1].trim());
            EnableSent = Boolean.parseBoolean(tokens[2].trim());
            MaxSessionTime = Integer.parseInt(tokens[3].trim());
            LastSessionTime = Integer.parseInt(tokens[4].trim());
            LifeThresholds[0] = Integer.parseInt(tokens[5].trim());
            LifeThresholds[1] = Integer.parseInt(tokens[6].trim());
            LifeThresholds[2] = Integer.parseInt(tokens[7].trim());
            LifeThresholds[3] = Integer.parseInt(tokens[8].trim());
            StringsCnt = Integer.parseInt(tokens[9].trim());
            InstrumentCnt = Integer.parseInt(tokens[10].trim());
            CurrSessionStart = tokens[11];
            StartT = Long.parseLong(tokens[12].trim());
            StopT = Long.parseLong(tokens[13].trim());
        }
    }

    // Method to save app run state to file (overwrites)
    public void saveRunState() {
        String delim = ", ";

        try {
            // note /system is a read-only file system so data is stored in /sdcard
            FileWriter filewriter = new FileWriter(path+filename, false);	// false = overwrite file
            PrintWriter outfile = new PrintWriter(filewriter);

            String outstr =
                    String.valueOf(InstrumentID)+delim+
                            String.valueOf(SessionStarted)+delim+
                            String.valueOf(EnableSent)+delim+
                            String.valueOf(MaxSessionTime)+delim+
                            String.valueOf(LastSessionTime)+delim+
                            String.valueOf(LifeThresholds[0])+delim+
                            String.valueOf(LifeThresholds[1])+delim+
                            String.valueOf(LifeThresholds[2])+delim+
                            String.valueOf(LifeThresholds[3])+delim+
                            String.valueOf(StringsCnt)+delim+
                            String.valueOf(InstrumentCnt)+delim+
                            CurrSessionStart+delim+
                            String.valueOf(StartT)+delim+
                            String.valueOf(StopT);

             outfile.println(outstr);
             outfile.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    /*/////////// Shared Preferences Storage Methods //////////////
    // Method to load app run state from app state file
    public void loadRunStateSP() {
        // Restore preferences
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        String line = settings.getString("appState", null);
        //line = getPreference(this.getBaseContext(),"appState");
        //parse if valid data
        if (line != null) {
            String tokens[] = line.split(",");

            InstrumentID = Integer.parseInt(tokens[0].trim());
            SessionStarted = Boolean.parseBoolean(tokens[1].trim());
            EnableSent = Boolean.parseBoolean(tokens[2].trim());
            MaxSessionTime = Integer.parseInt(tokens[3].trim());
            LastSessionTime = Integer.parseInt(tokens[4].trim());
            LifeThresholds[0] = Integer.parseInt(tokens[5].trim());
            LifeThresholds[1] = Integer.parseInt(tokens[6].trim());
            LifeThresholds[2] = Integer.parseInt(tokens[7].trim());
            LifeThresholds[3] = Integer.parseInt(tokens[8].trim());
            StringsCnt = Integer.parseInt(tokens[9].trim());
            InstrumentCnt = Integer.parseInt(tokens[10].trim());
            CurrSessionStart = tokens[11];
            StartT = Long.parseLong(tokens[12].trim());
            StopT = Long.parseLong(tokens[13].trim());
        }
    }

    // Method to save app run state to file (overwrites)
    public void saveRunStateSP() {
        String delim = ", ";

        String outstr =
                String.valueOf(InstrumentID)+delim+
                        String.valueOf(SessionStarted)+delim+
                        String.valueOf(EnableSent)+delim+
                        String.valueOf(MaxSessionTime)+delim+
                        String.valueOf(LastSessionTime)+delim+
                        String.valueOf(LifeThresholds[0])+delim+
                        String.valueOf(LifeThresholds[1])+delim+
                        String.valueOf(LifeThresholds[2])+delim+
                        String.valueOf(LifeThresholds[3])+delim+
                        String.valueOf(StringsCnt)+delim+
                        String.valueOf(InstrumentCnt)+delim+
                        CurrSessionStart+delim+
                        String.valueOf(StartT)+delim+
                        String.valueOf(StopT);

        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("appState", outstr);
        // Commit edits
        editor.commit();

   }

    // method returns true if app state file exists
    boolean fileExistsSP() {
        SharedPreferences settings = this.getBaseContext().getSharedPreferences(PREFS_NAME, 0);

        if(settings.getString("appState", null) != null){
             return true;
        } else {
            return false;
        }
    }

    // Method to init() the app which should run in main activity onCreate().
    // Checks for run state file existence then runs loadRunState() if run state file exists.
    // Otherwise it sets the FirstRun flag and returns value to main activity.
    // This implies default values are used.
    public boolean initSP() {
        if(fileExistsSP()) {
            loadRunStateSP();  // if file exists load the data
            FirstRun = false;
        } else {
            FirstRun = true;    // we may want to add other criterion here
        }
        return FirstRun;
    }

    // Methods to load and store Shared Preferences -- not used yet
    public static boolean setPreference(Context context, String key, String value) {
        SharedPreferences settings = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(key, value);
        return editor.commit();
    }

    public static String getPreference(Context context, String key) {
        SharedPreferences settings = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return settings.getString(key, "defaultValue");
    }

////////////////////////////////////////////////////////////////////////*/


    // getters
    int getInstrumentID() {
        return InstrumentID;
    }
    String getFilename() {
        return filename;     // read only
    }
    //boolean getSessionStarted() {
    //	return SessionStarted;
    //}
    boolean sessionStarted() {  // shorter name for ease of use
        return SessionStarted;
    }
    boolean getEnableSent() {
        return EnableSent;
    }
    int getMaxSessionTime() {
        return MaxSessionTime;
    }
    int getLastSessionTime() {
        return LastSessionTime;
    }
    int [] getLifeThresholds() {
        return LifeThresholds;
    }
    int getStringsCnt() {
        return StringsCnt;
    }
    int getInstrumentCnt() {
        return InstrumentCnt;
    }
    String getCurrSessionStart() {
        return CurrSessionStart;
    }

    // setters
    void setFirstRun(boolean f) {  // for debug purposes
        FirstRun = f;
    }
    void setInstrumentID(int iid) {
        InstrumentID = iid;
        System.out.println("*** InstrumentID = "+InstrumentID);
    }
    void setSessionStarted(boolean ss) {
        SessionStarted = ss;
    }
    void setEnableSent(boolean es) {
        EnableSent = es;
    }
    void setMaxSessionTime(int mt) {
        MaxSessionTime = mt;
    }
    void setLifeThresholds(int [] lt) {
        LifeThresholds = lt;
    }
    void setStringsCnt(int sc) {
        StringsCnt = sc;
    }
    void setInstrumentCnt(int ic) {
        InstrumentCnt =ic;
    }
    void setCurrSessionStart(String cs) {
        CurrSessionStart = cs;
    }
    void setTestMode(boolean b) { testMode = b; }

}
